#include <stdlib.h>
#include <string.h>


#define BUFER_MAX_LEN 50
void GenerateRandomText( const char* VariableName)
{
	char bufer[BUFER_MAX_LEN];
	unsigned int len = rand()%BUFER_MAX_LEN;
	unsigned int pos;
	
	
	for(pos = 0; pos < len; pos++ )
		bufer[pos] = 0x61+( rand()%26);	
	
	bufer[len]=0;
	
	lr_save_string(bufer,VariableName);
}