var addressbook_title ='Найдено в Адресной книге';
var InsertAddress = 1;
var addressbook = ["test_nt_2 \u003ctest_nt_2@mail.ru\u003e","test_ntt_2 \u003ctest_ntt_2@mail.ru\u003e","Mail.ru \u003csecurity@id.mail.ru\u003e","Почта Mail.ru \u003cwelcome@e.mail.ru\u003e"]
